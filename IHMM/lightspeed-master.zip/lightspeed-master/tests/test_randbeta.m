a=randbeta(1,ones(1,100000));
histc(a,0:.2:1)
